export const TOGGLE_THEME = "TOGGLE_THEME";

export const SALE_PRODUCT = "SALE_PRODUCT";


export const ADD_ITEM = "ADD_ITEM";
export const DELETE_ITEM = "DELETE_ITEM";
export const GET_ITEM = "GET_ITEM";
export const UPDATE_ITEM = "UPDATE_ITEM";



export const ADD_CONTACT = "ADD_CONTACT";
export const DELETE_CONTACT = "DELETE_CONTACT";
export const GET_CONTACT = "GET_CONTACT";
export const UPDATE_CONTACT = "UPDATE_CONTACT";

