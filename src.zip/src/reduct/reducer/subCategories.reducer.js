// // import { ADD_SUBCATEGORY, DELETE_SUBCATEGORY, GET_SUBCATEGORY, UPDATE_SUBCATEGORY } from "./action.type";

// const initialState = {
//     isLoading: false,
//     subcategory:[],
//     error:null
// }

// export const subcategoriesReduer = (state = initialState,action)=>{
//     console.log(action.payload);
//     switch(action.type){
//     case GET_SUBCATEGORY:
//         return{
//             ...state,
//             subcategory:action.payload,
//         };
//     case ADD_SUBCATEGORY:
//         return{
//             ...state,
//             subcategory:state.subcategory.concat(action.payload.data),
//         };
    
//     case DELETE_SUBCATEGORY:
//         return{
//             ...state,
//             subcategory:state.subcategory.filter((v) => v._id !== action.payload),
//         };
    
//     case UPDATE_SUBCATEGORY:
//         return{
//             ...state,
//             subcategory:state.subcategory.map((v) => v._id === action.payload._id ? action.payload : v),
//         };
//     default:
//         return state
//     }
// }