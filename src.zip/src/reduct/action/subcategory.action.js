// import axios from "axios";
// import { ADD_SUBCATEGORY, DELETE_SUBCATEGORY, GET_SUBCATEGORY, UPDATE_SUBCATEGORY } from "../reducer/action.type";

// export const getSubcategory = () => async (dispatch) =>{
//     try {
//       const response =  await axios.get("http://localhost:5000/api/v1/subcategories/list-subcategories")
//       dispatch({type: GET_SUBCATEGORY, payload: response.data.data})
//     } catch (error) {
//         console.log(error);
//     }
// }

// export const addSubcategory = (subcategory) => async (dispatch) =>{
//     try {
//       const response =  await axios.post("http://localhost:5000/api/v1/subcategories/add-subcategories",subcategory)
//       dispatch({type: ADD_SUBCATEGORY, payload: response.data.data})
//     } catch (error) {
//         console.log(error);
//     }
// }

// export const deleteSubcategory = (id) => async (dispatch) =>{
//     try {
//       const response =  await axios.delete(`http://localhost:5000/api/v1/subcategories/delete-subcategories/${id}`)
//       dispatch({type: DELETE_SUBCATEGORY, payload: response.id})
//     } catch (error) {
//         console.log(error);
//     }
// }

// export const updateSubcategory = (subcategory) => async (dispatch) =>{
//     try {
//       const response =  await axios.put(`http://localhost:3000/api/v1/subcategories/update-subcategories/${subcategory._id}`,subcategory)
//       dispatch({type: UPDATE_SUBCATEGORY, payload: response.data.data})
//     } catch (error) {
//         console.log(error);
//     }
// }